package com.cognizant.learntoday.service;

import java.util.List;

import com.cognizant.learntoday.model.Course;

public interface CourseService {

	public List<Course> getAllCourses();

	public Course getCourseById(int id);

}
