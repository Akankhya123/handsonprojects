package com.cognizant.learntoday.dao;

import java.util.List;

import com.cognizant.learntoday.model.Course;

public interface CourseDao {

	public List<Course> getAllCourses();
	
	public Course getCourseById(int id);
	
}
